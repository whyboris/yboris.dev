#pragma once

#include "globals.h"

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;


namespace VCDoodle {

	/// <summary>
	/// Summary for properties
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public ref class properties : public System::Windows::Forms::Form
	{
	public:
		properties(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~properties()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  btnOK;
	private: System::Windows::Forms::Button^  btnCancel;


	private: System::Windows::Forms::Label^  label1;

	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::CheckBox^  chkRandom;
	private: System::Windows::Forms::CheckBox^  chkBetween;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::NumericUpDown^  numericUpDown1;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::CheckBox^  chkBlackHoles;
	private: System::Windows::Forms::CheckBox^  chkNegGrav;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::NumericUpDown^  numericUpDown2;
	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::Label^  label8;
	private: System::Windows::Forms::NumericUpDown^  numericUpDown3;
	private: System::Windows::Forms::Label^  label9;
	private: System::Windows::Forms::NumericUpDown^  numericUpDown4;






	protected: 

	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->btnOK = (gcnew System::Windows::Forms::Button());
			this->btnCancel = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->chkRandom = (gcnew System::Windows::Forms::CheckBox());
			this->chkBetween = (gcnew System::Windows::Forms::CheckBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->numericUpDown1 = (gcnew System::Windows::Forms::NumericUpDown());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->chkBlackHoles = (gcnew System::Windows::Forms::CheckBox());
			this->chkNegGrav = (gcnew System::Windows::Forms::CheckBox());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->numericUpDown2 = (gcnew System::Windows::Forms::NumericUpDown());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->numericUpDown3 = (gcnew System::Windows::Forms::NumericUpDown());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->numericUpDown4 = (gcnew System::Windows::Forms::NumericUpDown());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown3))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown4))->BeginInit();
			this->SuspendLayout();
			// 
			// btnOK
			// 
			this->btnOK->Location = System::Drawing::Point(177, 217);
			this->btnOK->Name = L"btnOK";
			this->btnOK->Size = System::Drawing::Size(75, 23);
			this->btnOK->TabIndex = 0;
			this->btnOK->Text = L"OK";
			this->btnOK->UseVisualStyleBackColor = true;
			this->btnOK->Click += gcnew System::EventHandler(this, &properties::btnOK_Click);
			// 
			// btnCancel
			// 
			this->btnCancel->Location = System::Drawing::Point(96, 217);
			this->btnCancel->Name = L"btnCancel";
			this->btnCancel->Size = System::Drawing::Size(75, 23);
			this->btnCancel->TabIndex = 1;
			this->btnCancel->Text = L"Cancel";
			this->btnCancel->UseVisualStyleBackColor = true;
			this->btnCancel->Click += gcnew System::EventHandler(this, &properties::btnCancel_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(12, 26);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(94, 13);
			this->label1->TabIndex = 4;
			this->label1->Text = L"number of planets:";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(169, 26);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(54, 13);
			this->label2->TabIndex = 6;
			this->label2->Text = L"or random";
			// 
			// chkRandom
			// 
			this->chkRandom->AutoSize = true;
			this->chkRandom->Location = System::Drawing::Point(229, 26);
			this->chkRandom->Name = L"chkRandom";
			this->chkRandom->Size = System::Drawing::Size(15, 14);
			this->chkRandom->TabIndex = 7;
			this->chkRandom->UseVisualStyleBackColor = true;
			this->chkRandom->CheckedChanged += gcnew System::EventHandler(this, &properties::chkRandom_CheckedChanged);
			// 
			// chkBetween
			// 
			this->chkBetween->AutoSize = true;
			this->chkBetween->Location = System::Drawing::Point(212, 57);
			this->chkBetween->Name = L"chkBetween";
			this->chkBetween->Size = System::Drawing::Size(15, 14);
			this->chkBetween->TabIndex = 8;
			this->chkBetween->UseVisualStyleBackColor = true;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(29, 57);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(177, 13);
			this->label3->TabIndex = 9;
			this->label3->Text = L"place a planet between spaceships:";
			// 
			// numericUpDown1
			// 
			this->numericUpDown1->Location = System::Drawing::Point(112, 22);
			this->numericUpDown1->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {30, 0, 0, 0});
			this->numericUpDown1->Name = L"numericUpDown1";
			this->numericUpDown1->Size = System::Drawing::Size(51, 20);
			this->numericUpDown1->TabIndex = 10;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(29, 84);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(91, 13);
			this->label4->TabIndex = 11;
			this->label4->Text = L"allow black holes:";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(29, 111);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(171, 13);
			this->label5->TabIndex = 12;
			this->label5->Text = L"allow planets with negative gravity:";
			// 
			// chkBlackHoles
			// 
			this->chkBlackHoles->AutoSize = true;
			this->chkBlackHoles->Location = System::Drawing::Point(212, 84);
			this->chkBlackHoles->Name = L"chkBlackHoles";
			this->chkBlackHoles->Size = System::Drawing::Size(15, 14);
			this->chkBlackHoles->TabIndex = 13;
			this->chkBlackHoles->UseVisualStyleBackColor = true;
			// 
			// chkNegGrav
			// 
			this->chkNegGrav->AutoSize = true;
			this->chkNegGrav->Location = System::Drawing::Point(212, 111);
			this->chkNegGrav->Name = L"chkNegGrav";
			this->chkNegGrav->Size = System::Drawing::Size(15, 14);
			this->chkNegGrav->TabIndex = 14;
			this->chkNegGrav->UseVisualStyleBackColor = true;
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(12, 143);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(91, 13);
			this->label6->TabIndex = 15;
			this->label6->Text = L"speed of drawing:";
			// 
			// numericUpDown2
			// 
			this->numericUpDown2->Location = System::Drawing::Point(112, 139);
			this->numericUpDown2->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {20, 0, 0, 0});
			this->numericUpDown2->Name = L"numericUpDown2";
			this->numericUpDown2->Size = System::Drawing::Size(51, 20);
			this->numericUpDown2->TabIndex = 16;
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(169, 143);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(69, 13);
			this->label7->TabIndex = 17;
			this->label7->Text = L"(pause in ms)";
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Location = System::Drawing::Point(7, 176);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(99, 13);
			this->label8->TabIndex = 18;
			this->label8->Text = L"min radus of planet:";
			// 
			// numericUpDown3
			// 
			this->numericUpDown3->Location = System::Drawing::Point(112, 172);
			this->numericUpDown3->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) {50, 0, 0, 0});
			this->numericUpDown3->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) {1, 0, 0, 0});
			this->numericUpDown3->Name = L"numericUpDown3";
			this->numericUpDown3->Size = System::Drawing::Size(51, 20);
			this->numericUpDown3->TabIndex = 19;
			this->numericUpDown3->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) {1, 0, 0, 0});
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Location = System::Drawing::Point(169, 176);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(29, 13);
			this->label9->TabIndex = 20;
			this->label9->Text = L"max:";
			// 
			// numericUpDown4
			// 
			this->numericUpDown4->Location = System::Drawing::Point(204, 172);
			this->numericUpDown4->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) {2, 0, 0, 0});
			this->numericUpDown4->Name = L"numericUpDown4";
			this->numericUpDown4->Size = System::Drawing::Size(48, 20);
			this->numericUpDown4->TabIndex = 21;
			this->numericUpDown4->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) {2, 0, 0, 0});
			// 
			// properties
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(264, 251);
			this->Controls->Add(this->numericUpDown4);
			this->Controls->Add(this->label9);
			this->Controls->Add(this->numericUpDown3);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->numericUpDown2);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->chkNegGrav);
			this->Controls->Add(this->chkBlackHoles);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->numericUpDown1);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->chkBetween);
			this->Controls->Add(this->chkRandom);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->btnCancel);
			this->Controls->Add(this->btnOK);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedToolWindow;
			this->Name = L"properties";
			this->ShowInTaskbar = false;
			this->Text = L"properties";
			this->Load += gcnew System::EventHandler(this, &properties::properties_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown3))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->numericUpDown4))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnOK_Click(System::Object^  sender, System::EventArgs^  e) {
				 // save shit and then close

				 if (chkRandom->Checked == true){
					 randNumOfPlanets = true;
				 }else{
					 randNumOfPlanets = false;
				 }

				 if (chkBetween->Checked == true){
					 between = true;
				 }else{
					 between = false;
				 }

				 if (chkBlackHoles->Checked == true){
					 blackHoles = true;
				 }else{
					 blackHoles = false;
				 }

				 if (chkNegGrav->Checked == true){
					 negGravity = true;
				 }else{
					 negGravity = false;
				 }

				 int::TryParse(numericUpDown1->Text, numOfPlanets);

				 int::TryParse(numericUpDown2->Text, speed);

				 int::TryParse(numericUpDown3->Text, minr);

				 int::TryParse(numericUpDown4->Text, maxr);

				 if ( minr > maxr ){
					 minr = 7;
					 maxr = 55;
				 }
				 //newGame(); // how do I make it create a new game?

				 Close();
			 }

	private: System::Void btnCancel_Click(System::Object^  sender, System::EventArgs^  e) {
				 // don't save anything and close:
				 Close();
			 }

	private: System::Void properties_Load(System::Object^  sender, System::EventArgs^  e) {

				 if (randNumOfPlanets == true){
					 chkRandom->Checked = true;
					 numericUpDown1->Enabled = false;
				 }else{
					 chkRandom->Checked = false;
				 }

				 if (between == true){
					 chkBetween->Checked = true;
				 }else{
					 chkBetween->Checked = false;
				 }

				 if (negGravity == true){
					 chkNegGrav->Checked = true;
				 }else{
					 chkNegGrav->Checked = false;
				 }

				 if (blackHoles == true){
					 chkBlackHoles->Checked = true;
				 }else{
					 chkBlackHoles->Checked = false;
				 }

				 numericUpDown1->Text = "" + numOfPlanets;

				 numericUpDown2->Text = "" + speed;

				 numericUpDown3->Text = "" + minr;

				 numericUpDown4->Text = "" + maxr;

			 }

private: System::Void chkRandom_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
			 
			 if(chkRandom->Checked == true){
				 numericUpDown1->Enabled = false;
			 }else{
				 numericUpDown1->Enabled = true;
			 }

		 }

};
}
