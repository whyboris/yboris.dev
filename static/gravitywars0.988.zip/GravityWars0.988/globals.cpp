#include "stdafx.h"

int numOfPlanets; 
bool randNumOfPlanets;
bool between;

bool blackHoles;
bool negGravity;

int speed;
int minr;
int maxr;

int ss1colorr;
int ss1colorg;
int ss1colorb;



//int ss2color;
