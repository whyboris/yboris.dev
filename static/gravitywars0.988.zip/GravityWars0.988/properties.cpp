#include "StdAfx.h"
#include "properties.h"

