#ifndef NAMESPACE_FOO
#define NAMESPACE_FOO

	extern int numOfPlanets; 
	extern bool randNumOfPlanets;
	extern bool between;

	extern bool blackHoles;
	extern bool negGravity;

	extern int speed;

	extern int minr;
	extern int maxr;

#endif
